data class MenuItem(
    val itemId: String = "",
    val dishName: String = "",
    val price: Double = 0.0
)