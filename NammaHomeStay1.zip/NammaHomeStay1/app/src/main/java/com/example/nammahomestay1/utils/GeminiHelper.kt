package com.example.nammahomestay1.utils

import com.google.ai.client.generativeai.GenerativeModel

class GeminiHelper {

    private val apiKey = "AIzaSyAEfCTT_p-zrdzHbcbg9Fgw-7KiQyPEKcc"

    private val generativeModel = GenerativeModel(
        modelName = "gemini-2.0-flash",
        apiKey = apiKey
    )

    suspend fun generateMenuDescription(
        dishName: String
    ): String {

        return when (dishName.lowercase()) {

            "bamboo shoot curry" ->
                "Traditional coastal delicacy prepared with fresh bamboo shoots and aromatic spices."

            "akki rotti" ->
                "Authentic Karnataka flatbread served hot with chutney and local flavors."

            "neer dosa" ->
                "Soft coastal Karnataka dosa served with spicy curry and coconut chutney."

            "fish fry" ->
                "Fresh fish marinated with traditional coastal spices and fried to perfection."

            else ->
                "$dishName is a delicious homemade specialty loved by travelers."
        }
    }

    suspend fun generateTravelGuide(
        placeName: String
    ): String {

        return when (placeName.lowercase()) {

            "coorg" ->
                "Coorg is famous for coffee plantations, waterfalls, misty hills, trekking, and peaceful nature stays."

            "chikmagalur" ->
                "Chikmagalur is known for scenic mountains, coffee estates, waterfalls, and adventure tourism."

            "udupi" ->
                "Udupi is popular for beaches, temples, delicious coastal cuisine, and cultural heritage."

            "gokarna" ->
                "Gokarna is famous for beautiful beaches, spiritual temples, beach trekking, and peaceful sunsets."

            "mullayanagiri" ->
                "Mullayanagiri is the highest peak in Karnataka known for trekking, mountain views, and cool climate."

            else ->
                "$placeName is a beautiful tourist destination known for nature, culture, local food, and unique travel experiences."
        }
    }
}