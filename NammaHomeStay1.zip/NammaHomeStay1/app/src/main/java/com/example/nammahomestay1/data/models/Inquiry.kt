data class Inquiry(
    val msgId: String = "",
    val travellerName: String = "",
    val message: String = ""
)