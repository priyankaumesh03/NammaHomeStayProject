package com.example.nammahomestay1.ui.inquiry

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun InquiryScreen() {

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        item {

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF2E7D32)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(24.dp)
                ) {

                    Text(
                        text = "📞 Contact & Inquiry",
                        fontSize = 30.sp,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Connect with our homestay team for bookings, travel assistance, and local guidance.",
                        color = Color.White
                    )
                }
            }
        }

        item {

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE8F5E9)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(20.dp)
                ) {

                    Text(
                        text = "🏡 Sids Farm Homestay",
                        fontSize = 24.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "📍 Chikmagalur, Karnataka"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "🕒 Open: 24 Hours"
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {

                            val gmmIntentUri = Uri.parse(
                                "geo:0,0?q=Sids Farm Homestay Chikmagalur"
                            )

                            val mapIntent = Intent(
                                Intent.ACTION_VIEW,
                                gmmIntentUri
                            )

                            mapIntent.setPackage(
                                "com.google.android.apps.maps"
                            )

                            context.startActivity(mapIntent)
                        },

                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Text(
                            text = "📍 View Location"
                        )
                    }
                }
            }
        }

        item {

            Button(
                onClick = {

                    val intent = Intent(
                        Intent.ACTION_DIAL
                    ).apply {

                        data = Uri.parse(
                            "tel:9876543210"
                        )
                    }

                    context.startActivity(intent)
                },

                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = "📞 Call Reception"
                )
            }
        }

        item {

            Button(
                onClick = {

                    val intent = Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse(
                            "https://wa.me/919876543210"
                        )
                    )

                    context.startActivity(intent)
                },

                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = "📱 WhatsApp Booking"
                )
            }
        }
    }
}