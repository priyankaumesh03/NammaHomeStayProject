package com.example.nammahomestay1.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import com.example.nammahomestay1.R
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.nammahomestay1.ui.guide.GuideScreen
import com.example.nammahomestay1.ui.inquiry.InquiryScreen
import com.example.nammahomestay1.ui.menu.MenuScreen
import com.example.nammahomestay1.ui.profile.ProfileScreen
import com.example.nammahomestay1.ui.travel.TravelScreen

@Composable
fun DashboardScreen() {

    var selectedTab by remember {
        mutableStateOf(0)
    }

    Scaffold(

        bottomBar = {

            NavigationBar {

                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text("Home") },
                    icon = { Text("🏠") }
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    label = { Text("Menu") },
                    icon = { Text("🍛") }
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    label = { Text("Guide") },
                    icon = { Text("🗺️") }
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    label = { Text("Inquiry") },
                    icon = { Text("💬") }
                )

                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    label = { Text("Profile") },
                    icon = { Text("👤") }
                )

                NavigationBarItem(
                    selected = selectedTab == 5,
                    onClick = { selectedTab = 5 },
                    label = { Text("Travel") },
                    icon = { Text("✈️") }
                )
            }
        }

    ) { paddingValues ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {

            when (selectedTab) {

                0 -> {

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),

                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {

                        Card(
                            modifier = Modifier.fillMaxWidth()
                        ) {

                            Column(
                                modifier = Modifier
                                    .background(Color(0xFF2E7D32))
                                    .padding(24.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.banner),
                                    contentDescription = null,

                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(220.dp),

                                    contentScale = ContentScale.Crop
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Text(
                                    text = "🏡 Namma HomeStay",
                                    fontSize = 30.sp,
                                    color = Color.White
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "Explore Rural Tourism • Local Food • Nature • Culture",
                                    color = Color.White
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Experience village lifestyle, traditional cuisine, peaceful stays, and unforgettable travel memories.",
                                    color = Color.White
                                )
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFE8F5E9)
                            ),

                            modifier = Modifier.fillMaxWidth()
                        ) {

                            Column(
                                modifier = Modifier.padding(20.dp)
                            ) {

                                Text(
                                    text = "🏡 Sids Farm Homestay",
                                    fontSize = 24.sp
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "📍 Chikmagalur, Karnataka"
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "A peaceful eco-friendly farm stay surrounded by coffee plantations, traditional cuisine, village lifestyle, and scenic mountain views."
                                )
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFFFF3E0)
                            ),

                            modifier = Modifier.fillMaxWidth()
                        ) {

                            Column(
                                modifier = Modifier.padding(20.dp)
                            ) {

                                Text(
                                    text = "🍛 Today's Special",
                                    fontSize = 20.sp
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Bamboo Shoot Curry"
                                )
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFFFF8E1)
                            ),

                            modifier = Modifier.fillMaxWidth()
                        ) {

                            Column(
                                modifier = Modifier.padding(20.dp)
                            ) {

                                Text(
                                    text = "🔥 Best Offer Today",
                                    fontSize = 20.sp
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "Stay 2 Nights & Get Free Traditional Breakfast"
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Special Dish: Neer Dosa with Coconut Chutney"
                                )
                            }
                        }

                        Text(
                            text = "📊 Quick Stats",
                            fontSize = 22.sp
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFFE3F2FD)
                                ),

                                modifier = Modifier
                                    .weight(1f)
                                    .height(120.dp)
                            ) {

                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),

                                    verticalArrangement = Arrangement.Center
                                ) {

                                    Text(
                                        text = "25+",
                                        fontSize = 26.sp
                                    )

                                    Text(
                                        text = "Homestays"
                                    )
                                }
                            }

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFFFFF9C4)
                                ),

                                modifier = Modifier
                                    .weight(1f)
                                    .height(120.dp)
                            ) {

                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),

                                    verticalArrangement = Arrangement.Center
                                ) {

                                    Text(
                                        text = "50+",
                                        fontSize = 26.sp
                                    )

                                    Text(
                                        text = "Tourists"
                                    )
                                }
                            }
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFFFEBEE)
                            ),

                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                        ) {

                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),

                                verticalArrangement = Arrangement.Center
                            ) {

                                Text(
                                    text = "100+",
                                    fontSize = 26.sp
                                )

                                Text(
                                    text = "Traditional Foods"
                                )
                            }
                        }

                        Text(
                            text = "🌍 Popular Destinations",
                            fontSize = 22.sp
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {

                            items(
                                listOf(
                                    "🌿 Coorg",
                                    "⛰️ Chikmagalur",
                                    "🏖️ Udupi",
                                    "🌊 Gokarna"
                                )
                            ) { place ->

                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = Color(0xFFFFF3E0)
                                    ),

                                    modifier = Modifier.width(180.dp)
                                ) {

                                    Column(
                                        modifier = Modifier.padding(16.dp)
                                    ) {

                                        Text(
                                            text = place,
                                            fontSize = 20.sp
                                        )

                                        Spacer(
                                            modifier = Modifier.height(8.dp)
                                        )

                                        Text(
                                            text = "Explore beautiful nature, food, culture, and peaceful stays."
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    MenuScreen()
                }

                2 -> {
                    GuideScreen()
                }

                3 -> {
                    InquiryScreen()
                }

                4 -> {
                    ProfileScreen()
                }

                else -> {
                    TravelScreen()
                }
            }
        }
    }
}