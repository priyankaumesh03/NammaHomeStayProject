class FirestoreRepository {

    fun testConnection(): String {
        return "Firebase Repository Ready"
    }
}