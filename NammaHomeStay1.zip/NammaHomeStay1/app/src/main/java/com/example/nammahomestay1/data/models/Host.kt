data class Host(
    val hostId: String = "",
    val name: String = "",
    val homeStayName: String = "",
    val phone: String = ""
)