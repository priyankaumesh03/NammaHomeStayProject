package com.example.nammahomestay1.ui.menu

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Dish(
    val name: String,
    val price: String,
    val description: String,
    val category: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen() {

    var dishName by remember { mutableStateOf("") }
    var dishPrice by remember { mutableStateOf("") }

    val categories = listOf(
        "Breakfast",
        "Drinks",
        "Lunch",
        "Dinner",
        "Starters",
        "Specials"
    )

    var selectedCategory by remember {
        mutableStateOf(categories[0])
    }

    var expanded by remember {
        mutableStateOf(false)
    }

    val dishes = remember {

        mutableStateListOf(

            Dish(
                "Mallige Idli",
                "₹80",
                "Soft traditional Karnataka idlis served with chutney.",
                "Breakfast"
            ),

            Dish(
                "Filter Coffee",
                "₹40",
                "Authentic South Indian filter coffee.",
                "Drinks"
            ),

            Dish(
                "Chicken Biryani",
                "₹220",
                "Spicy homestyle biryani prepared with local spices.",
                "Lunch"
            ),

            Dish(
                "Neer Dosa",
                "₹120",
                "Soft coastal Karnataka dosa served fresh.",
                "Dinner"
            ),

            Dish(
                "Fish Fry",
                "₹250",
                "Fresh fish marinated with traditional masala.",
                "Starters"
            ),

            Dish(
                "Bamboo Shoot Curry",
                "₹180",
                "Traditional seasonal delicacy from Malnad region.",
                "Specials"
            )
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        item {

            Text(
                text = "🍛 Traditional Homestay Menu",
                fontSize = 28.sp
            )
        }

        item {

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE8F5E9)
                )
            ) {

                Column(
                    modifier = Modifier.padding(16.dp)
                ) {

                    Text(
                        text = "➕ Add New Dish",
                        fontSize = 22.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = dishName,
                        onValueChange = {
                            dishName = it
                        },
                        label = {
                            Text("Dish Name")
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = dishPrice,
                        onValueChange = {
                            dishPrice = it
                        },
                        label = {
                            Text("Dish Price")
                        },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = {
                            expanded = !expanded
                        }
                    ) {

                        OutlinedTextField(
                            value = selectedCategory,
                            onValueChange = {},
                            readOnly = true,
                            label = {
                                Text("Category")
                            },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )

                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = {
                                expanded = false
                            }
                        ) {

                            categories.forEach { category ->

                                DropdownMenuItem(
                                    text = {
                                        Text(category)
                                    },

                                    onClick = {

                                        selectedCategory = category
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {

                            val description =
                                "$dishName is a delicious homestay specialty prepared with authentic local flavors."

                            dishes.add(

                                Dish(
                                    dishName,
                                    "₹$dishPrice",
                                    description,
                                    selectedCategory
                                )
                            )

                            dishName = ""
                            dishPrice = ""
                        },

                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Text("Add Dish")
                    }
                }
            }
        }

        categories.forEach { category ->

            item {

                Text(
                    text = category,
                    fontSize = 24.sp
                )
            }

            items(

                dishes.filter {
                    it.category == category
                }

            ) { dish ->

                Card(

                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFFFF8E1)
                    ),

                    modifier = Modifier.fillMaxWidth()
                ) {

                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {

                        Text(
                            text = dish.name,
                            fontSize = 22.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = dish.price,
                            fontSize = 18.sp,
                            color = Color(0xFF2E7D32)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = dish.description
                        )
                    }
                }
            }
        }
    }
}