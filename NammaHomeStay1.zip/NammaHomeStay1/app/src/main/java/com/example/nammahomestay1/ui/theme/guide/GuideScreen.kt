package com.example.nammahomestay1.ui.guide

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nammahomestay1.utils.GeminiHelper
import kotlinx.coroutines.launch

@Composable
fun GuideScreen() {

    var placeName by remember {
        mutableStateOf("")
    }

    var aiGuide by remember {
        mutableStateOf("")
    }

    val scope = rememberCoroutineScope()

    val geminiHelper = remember {
        GeminiHelper()
    }

    val attractions = listOf(
        "🌄 Mullayanagiri",
        "🌊 Jhari Falls",
        "☕ Coffee Estates",
        "🛕 Baba Budangiri",
        "🏞️ Hebbe Falls"
    )

    val foods = listOf(
        "🍛 Bamboo Shoot Curry",
        "🥞 Neer Dosa",
        "☕ Filter Coffee",
        "🍚 Akki Rotti",
        "🍲 Chicken Curry"
    )

    val tips = listOf(
        "Carry rain jackets during monsoon.",
        "Best season: October to February.",
        "Try authentic local Malnad cuisine.",
        "Visit coffee plantations early morning.",
        "Wear trekking shoes for hill visits."
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        item {

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFF2E7D32)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(24.dp)
                ) {

                    Text(
                        text = "🧭 Local Travel Guide",
                        fontSize = 30.sp,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Explore nature, waterfalls, coffee estates, food culture, and hidden gems of Karnataka.",
                        color = Color.White
                    )
                }
            }
        }

        item {

            Text(
                text = "🌍 Popular Attractions",
                fontSize = 24.sp
            )
        }

        item {

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                items(attractions) { place ->

                    Card(

                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFE8F5E9)
                        ),

                        modifier = Modifier.width(220.dp)
                    ) {

                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {

                            Text(
                                text = place,
                                fontSize = 20.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Beautiful tourist attraction surrounded by nature and scenic views."
                            )
                        }
                    }
                }
            }
        }

        item {

            Text(
                text = "🍛 Famous Local Foods",
                fontSize = 24.sp
            )
        }

        item {

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                items(foods) { food ->

                    Card(

                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFFFFF3E0)
                        ),

                        modifier = Modifier.width(220.dp)
                    ) {

                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {

                            Text(
                                text = food,
                                fontSize = 20.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Traditional homestay delicacy loved by travelers."
                            )
                        }
                    }
                }
            }
        }

        item {

            Text(
                text = "📍 Travel Tips",
                fontSize = 24.sp
            )
        }

        items(tips) { tip ->

            Card(

                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE3F2FD)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Text(
                    text = tip,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        item {

            Card(

                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFF3E5F5)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(20.dp)
                ) {

                    Text(
                        text = "🤖 AI Travel Assistant",
                        fontSize = 22.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = placeName,
                        onValueChange = {
                            placeName = it
                        },

                        label = {
                            Text("Enter Tourist Place")
                        },

                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {

                            scope.launch {

                                aiGuide =
                                    geminiHelper.generateTravelGuide(placeName)
                            }
                        },

                        modifier = Modifier.fillMaxWidth()
                    ) {

                        Text("✨ Generate Guide")
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = aiGuide
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Use the Travel tab to generate AI-powered tourism recommendations and local travel guidance."
                    )
                }
            }
        }
    }
}