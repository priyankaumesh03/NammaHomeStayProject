class ImageUploadHelper {

    fun uploadImage(): String {
        return "Image Uploaded Successfully"
    }
}