data class LocalSpot(
    val spotId: String = "",
    val name: String = "",
    val description: String = ""
)