package com.example.nammahomestay1.ui.profile

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

data class SavedProfile(
    val owner: String,
    val homestay: String,
    val price: String,
    val description: String
)

data class Review(
    val name: String,
    val comment: String
)

@Composable
fun ProfileScreen() {

    val db = Firebase.firestore

    var ownerName by remember {
        mutableStateOf("")
    }

    var homestayName by remember {
        mutableStateOf("")
    }

    var price by remember {
        mutableStateOf("")
    }

    var description by remember {
        mutableStateOf("")
    }

    var savedProfile by remember {
        mutableStateOf<SavedProfile?>(null)
    }

    var reviewName by remember {
        mutableStateOf("")
    }

    var reviewComment by remember {
        mutableStateOf("")
    }

    val reviews = remember {

        mutableStateListOf(

            Review(
                "Rahul",
                "Beautiful peaceful stay with amazing food."
            ),

            Review(
                "Priya",
                "Loved the coffee plantation views and hospitality."
            )
        )
    }

    val imageList = remember {
        mutableStateListOf<Uri>()
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris ->

        imageList.clear()
        imageList.addAll(uris)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),

        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF2E7D32)
            ),

            modifier = Modifier.fillMaxWidth()
        ) {

            Column(
                modifier = Modifier.padding(24.dp)
            ) {

                Text(
                    text = "👤 Homestay Profile",
                    fontSize = 30.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Manage your homestay information, gallery, guest reviews, and profile details.",
                    color = Color.White
                )
            }
        }

        OutlinedTextField(
            value = ownerName,
            onValueChange = {
                ownerName = it
            },

            label = {
                Text("Owner Name")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = homestayName,
            onValueChange = {
                homestayName = it
            },

            label = {
                Text("Homestay Name")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = price,
            onValueChange = {
                price = it
            },

            label = {
                Text("Price Per Night")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = description,
            onValueChange = {
                description = it
            },

            label = {
                Text("Homestay Description")
            },

            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                launcher.launch("image/*")
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "🖼️ Select Homestay Images"
            )
        }

        if (imageList.isNotEmpty()) {

            Text(
                text = "📸 Selected Images",
                fontSize = 22.sp
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                items(imageList) { imageUri ->

                    Card {

                        AsyncImage(
                            model = imageUri,
                            contentDescription = null,

                            modifier = Modifier
                                .width(180.dp)
                                .height(180.dp)
                        )
                    }
                }
            }
        }

        Button(
            onClick = {

                val profileData = hashMapOf(

                    "ownerName" to ownerName,
                    "homestayName" to homestayName,
                    "price" to price,
                    "description" to description
                )

                db.collection("profiles")
                    .add(profileData)

                savedProfile = SavedProfile(
                    ownerName,
                    homestayName,
                    price,
                    description
                )
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "💾 Save Profile"
            )
        }

        savedProfile?.let { profile ->

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE8F5E9)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(20.dp)
                ) {

                    Text(
                        text = "🏡 ${profile.homestay}",
                        fontSize = 24.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "👤 Owner: ${profile.owner}"
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "💰 ₹${profile.price} / night"
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = profile.description
                    )
                }
            }
        }

        Text(
            text = "⭐ Guest Reviews",
            fontSize = 24.sp
        )

        OutlinedTextField(
            value = reviewName,
            onValueChange = {
                reviewName = it
            },

            label = {
                Text("Your Name")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = reviewComment,
            onValueChange = {
                reviewComment = it
            },

            label = {
                Text("Write Review")
            },

            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {

                if (
                    reviewName.isNotEmpty() &&
                    reviewComment.isNotEmpty()
                ) {

                    reviews.add(
                        Review(
                            reviewName,
                            reviewComment
                        )
                    )

                    reviewName = ""
                    reviewComment = ""
                }
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "⭐ Submit Review"
            )
        }

        reviews.forEach { review ->

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFFFF8E1)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(16.dp)
                ) {

                    Text(
                        text = "⭐ ${review.name}",
                        fontSize = 20.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = review.comment
                    )
                }
            }
        }
    }
}