package com.example.nammahomestay1.ui.travel

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Booking(
    val name: String,
    val phone: String,
    val guests: String,
    val checkIn: String,
    val checkOut: String
)

@Composable
fun TravelScreen() {

    var name by remember {
        mutableStateOf("")
    }

    var phone by remember {
        mutableStateOf("")
    }

    var guests by remember {
        mutableStateOf("")
    }

    var checkIn by remember {
        mutableStateOf("")
    }

    var checkOut by remember {
        mutableStateOf("")
    }

    var bookingDone by remember {
        mutableStateOf(false)
    }

    var savedBooking by remember {
        mutableStateOf<Booking?>(null)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),

        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {

        Card(
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFF2E7D32)
            ),

            modifier = Modifier.fillMaxWidth()
        ) {

            Column(
                modifier = Modifier.padding(24.dp)
            ) {

                Text(
                    text = "✈️ Travel & Booking",
                    fontSize = 30.sp,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Book peaceful farm stays, local food experiences, and authentic Karnataka tourism.",
                    color = Color.White
                )
            }
        }

        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
            },

            label = {
                Text("Guest Name")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = phone,
            onValueChange = {
                phone = it
            },

            label = {
                Text("Phone Number")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = guests,
            onValueChange = {
                guests = it
            },

            label = {
                Text("Number of Guests")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = checkIn,
            onValueChange = {
                checkIn = it
            },

            label = {
                Text("Check-In Date")
            },

            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = checkOut,
            onValueChange = {
                checkOut = it
            },

            label = {
                Text("Check-Out Date")
            },

            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {

                savedBooking = Booking(
                    name,
                    phone,
                    guests,
                    checkIn,
                    checkOut
                )

                bookingDone = true
            },

            modifier = Modifier.fillMaxWidth()
        ) {

            Text(
                text = "🛏️ Book Now"
            )
        }

        if (bookingDone) {

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE8F5E9)
                ),

                modifier = Modifier.fillMaxWidth()
            ) {

                Column(
                    modifier = Modifier.padding(20.dp)
                ) {

                    Text(
                        text = "✅ Booking Confirmed",
                        fontSize = 24.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    savedBooking?.let { booking ->

                        Text(
                            text = "👤 Guest: ${booking.name}"
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "📞 Phone: ${booking.phone}"
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "👥 Guests: ${booking.guests}"
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "📅 Check-In: ${booking.checkIn}"
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "📅 Check-Out: ${booking.checkOut}"
                        )
                    }
                }
            }
        }
    }
}